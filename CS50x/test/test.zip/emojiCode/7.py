print("🤷 ", end="")
text = input()
print("👋 " + text)