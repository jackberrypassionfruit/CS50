from random import randint

print(randint(0, 9))